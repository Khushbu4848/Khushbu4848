//
//  Context.swift
//  FrenchVerbAPIPlayground
//
//  Created by english on 2023-12-05.
//

import Foundation
class Context{
    static var loggedUserToken: String?

}
