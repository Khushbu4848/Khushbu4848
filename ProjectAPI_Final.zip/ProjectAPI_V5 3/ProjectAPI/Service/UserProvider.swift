//
//  File.swift
//  ProjectAPI
//
//  Created by english on 2023-11-30.
//

import Foundation

class UserProvider{
    static var allUsers = [User(username:" Preet",password: "123"),
                           User(username:" Jashan",password: "123"),
                           User(username:" Khusbu",password: "123"),
                           User(username:" Kuiri",password: "123")
    ]
}
