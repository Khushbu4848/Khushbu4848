//
//  enumSegue.swift
//  MidtermFall2023
//
//  Created by Daniel Carvalho on 24/10/23.
//

import Foundation

enum Segue {
    
    static let toSignInViewController = "toSignInViewController"

    static let toLogInViewController = "toLogInViewController"
    
    static let toVerbTableViewController = "toVerbTableViewController"
                                            
    
    
}
